<?php
session_start();
include '../booksite_mysqli.php';

// Check if the username and password are set
if (isset($_POST['username']) && isset($_POST['password'])) {
    $user = trim($_POST['username']);
    $pass = trim($_POST['password']);

    // Query to retrieve the user's ID and hashed password from the database
    $login_query = "SELECT UserID, Password FROM Users WHERE Username = '" . $user . "'";
    $login_result = mysqli_query($conn, $login_query);
    $login_record = mysqli_fetch_assoc($login_result);

    // Check if a record was found and the password matches
    if ($login_record && password_verify($pass, $login_record['Password'])) {
        // Set user session variables
        $_SESSION['user_id'] = $login_record['UserID'];
        $_SESSION['logged_in'] = 1;
    }
}

header("Location: favourites.php");
exit;
?>
