<?php
/* Include the database connection */
include '../booksite_mysqli.php';

// Function to check if a user with the given username exists
function userExists($conn, $username) {
    $stmt = $conn->prepare("SELECT UserID FROM Users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();
    return $stmt->num_rows > 0;
}

session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check which form was submitted
    if (isset($_POST['login_form'])) {
        // Login form submitted
        $username = $_POST['username'];
        $password = $_POST['password'];

        $stmt = $conn->prepare("SELECT UserID, username, password FROM Users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            if (password_verify($password, $row['password'])) {
                // Password is correct, set user session
                $_SESSION['user_id'] = $row['UserID'];
                $_SESSION['logged_in'] = 1;
                header("Location: favourites.php");
                exit;
            } else {
                echo "<p>Incorrect password. Please try again.</p>";
            }
        } else {
            echo "<p>Username not found. Please check your username.</p>";
        }
    } elseif (isset($_POST['createacc_form'])) {
        // Create account form submitted
        $username = $_POST['username'];
        $password = $_POST['password'];

        // Validate input data
        $username = htmlspecialchars($username);

        if (strlen($username) > 30) {
            echo "<p>Username is too long. Please choose a username with 30 characters or less.</p>";
        } elseif (userExists($conn, $username)) {
            echo "<p>Username already exists. Please choose a different username.</p>";
        } else {
            // Hash the password
            $passwordHash = password_hash($password, PASSWORD_BCRYPT);

            // Insert the new user into the database
            $stmt = $conn->prepare("INSERT INTO Users (username, password) VALUES (?, ?)");
            $stmt->bind_param("ss", $username, $passwordHash);

            if ($stmt->execute()) {
                // Automatically log in the new user
                $_SESSION['user_id'] = $stmt->insert_id;
                $_SESSION['logged_in'] = 1;
                header("Location: favourites.php");
                exit;
            } else {
                echo "Error: " . $stmt->error;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Header -->
    <header>
        <h1>Book Nook</h1>
    </header>

    <!-- Navigation Bar -->
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="books.php">Books</a></li>
            <li><a href="login.php">Login</a></li>
            <li><a href="favourites.php">Favourites</a></li>
        </ul>
        <?php
        if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == 1) {
            echo '<form action="logout.php" method="post" class="login">
            <button type="submit" name="logoutbutton">Logout</button>
            </form>';
        }
        ?>
    </nav>

    <!-- Body Content -->
    <section>
        <h2>Login</h2>
        <div class='forms'>
            <form name='login_form' id='login_form' method='post' action='process_login.php'>
                <p>If you're visiting our website again, log in to your account here</p><br>
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" placeholder="Username" required><br>
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" placeholder="Password" required><br><br>
                <button type="submit" name="login_form">Log In</button>
            </form>
        </div>
        <h2>Create Account</h2>
        <div class='forms'>
            <form name='createacc_form' id='createacc_form' method='post' action='login.php'>
                <p>If you're new to our website, create a new account here</p><br>
                <label for="new_username">Username:</label>
                <input type="text" id="new_username" name="username" placeholder="Username" required><br>
                <label for="new_password">Password:</label>
                <input type="password" id="new_password" name="password" placeholder="Password" required><br><br>
                <button type="submit" name="createacc_form">Create Account</button>
            </form>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <p>&copy; 2023 Gabrielle's Website. All rights reserved.</p>
    </footer>
</body>
</html>
