<?php
include '../booksite_mysqli.php';
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] != 1) {
    header("Location: error_login.php");
    exit;
}

// Fetch the user's username from the database
if (isset($_SESSION['user_id'])) {
    $userID = $_SESSION['user_id'];

    $query = "SELECT Username FROM Users WHERE UserID = $userID";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $username = $row['Username'];
    } else {
        // Username couldn't be retrieved
        $username = "User";
    }
} else {
    // User_id is not set
    $username = "User";
}

// Handle book deletion
if (isset($_POST['deletebutton']) && isset($_POST['book_id'])) {
    $userID = $_SESSION['user_id'];
    $bookID = $_POST['book_id'];

    // Perform the deletion from the Favorites table
    $query = "DELETE FROM Favourites WHERE UserID = $userID AND BookID = $bookID";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $_SESSION['success_msg'] = "Book deleted from your favorites successfully.";
        header("Location: favourites.php");
        exit;
    } else {
        $deleteError = "Error: Unable to delete the book from favorites.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $username; ?>'s Favorites</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<!-- Header -->
<header>
    <h1>Book Nook</h1>
</header>

<!-- Navigation Bar -->
<nav>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="books.php">Books</a></li>
        <li><a href="login.php">Login</a></li>
        <li><a href="favourites.php">Favorites</a></li>
    </ul>
    <?php
    if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == 1) {
        echo '<form action="logout.php" method="post" class="login">
      <button type="submit" name="logoutbutton">Logout</button>
      </form></div>';
    }
    ?>
</nav>

<!-- Body Content -->
<section>
    <h2><?php echo $username; ?>'s Favorites</h2>
    <?php
    if (isset($_SESSION['success_msg'])) {
        echo "<p>" . $_SESSION['success_msg'] . "</p>";

        // Clear success message from the session after displaying it
        unset($_SESSION['success_msg']);
    }

    // Fetch favourite books for the logged-in user
    if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == 1) {
        if (isset($_SESSION['user_id'])) { // Check if user_id is set
            $userID = $_SESSION['user_id'];

            $query = "SELECT * FROM Favourites
              JOIN Books ON Favourites.BookID = Books.BookID
              JOIN Authors ON Books.AuthorID = Authors.AuthorID
              JOIN Publishers ON Books.PubID = Publishers.PubID
              WHERE Favourites.UserID = $userID";
            $result = mysqli_query($conn, $query);

            // Display favourite books
            echo "<div class='book-list'>";
            if ($result && mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_array($result)) {
                    echo "<div class='book-list-item'><img src='images/" . $row['Cover'] . "' alt='" . $row['Title'] . "'>";
                    echo "<h3>" . $row['Title'] . "</h3><p>by " . $row['Fname'] . " " . $row['Lname'] .
                        "<br>Publisher: " . $row['Name'] . "<br>Year Published: " . $row['PubYr'] . "</p><br>";

                    // Add a form to delete the book from favorites
                    echo "<form action='favourites.php' method='post'>";
                    echo "<input type='hidden' name='book_id' value='" . $row['BookID'] . "'>";
                    echo "<button type='submit' name='deletebutton'>Delete from Favorites</button>";
                    echo "</form>";

                    echo "</div>";
                }
            } else {
                echo "<p>No favorite books found.</p>";
            }
            echo "</div>";
        } else {
            echo "<p>Your user ID is not set. There is an issue with your login process.</p>";
        }
    } else {
        echo "<p>You must be logged in to view your favorites.</p>";
    }
    ?>
</section>

<!-- Footer -->
<footer>
    <p>&copy; 2023 Gabrielle's Website. All rights reserved.</p>
</footer>
</body>
</html>
