<?php
// Include database connection
include '../booksite_mysqli.php';

session_start();

// Function to fetch authors
function getAuthors($conn) {
    $authors = array();
    $query = "SELECT AuthorID, CONCAT(Fname, ' ', Lname) AS AuthorName FROM Authors";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $authors[$row['AuthorID']] = $row['AuthorName'];
        }
    }
    return $authors;
}

// Function to fetch publishers
function getPublishers($conn) {
    $publishers = array();
    $query = "SELECT PubID, Name FROM Publishers";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $publishers[$row['PubID']] = $row['Name'];
        }
    }
    return $publishers;
}

// Function to check for numeric and minimum/maximum values
function checkInput($value, $fieldName, $function, $book) {
    if ($fieldName === 'Year Published' && !is_numeric($value)) {
        echo "<p>Error $function $book: $fieldName must be a number.</p><br>";
        return false;
    }
    if ($fieldName === 'Year Published' && ($value < 0 || $value > 9999)) {
        echo "<p>Error $function $book: $fieldName must be between 0 and 9999.</p><br>";
        return false;
    }
    return true;
}

// Function to check for duplicate entries
function checkForDuplicate($conn, $tableName, $columns, $values) {
    $placeholders = array_fill(0, count($columns), "?");
    $placeholders = implode(", ", $placeholders);
    $query = "SELECT COUNT(*) FROM $tableName WHERE (" . implode(", ", $columns) . ") = ($placeholders)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, str_repeat("s", count($values)), ...$values);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $duplicateCount);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);
    return $duplicateCount > 0;
}

$authors = getAuthors($conn);
$publishers = getPublishers($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Books</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<!-- Header -->
<header>
    <h1>Book Nook</h1>
</header>

<!-- Navigation Bar -->
<nav>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="books.php">Books</a></li>
        <li><a href="login.php">Login</a></li>
        <li><a href="favourites.php">Favourites</a></li>
    </ul>
    <?php
    if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == 1) {
        echo '<form action="logout.php" method="post" class="login">
            <button type="submit" name="logoutbutton">Logout</button>
        </form></div>';
    }
    ?>
</nav>

<!-- Body Content -->
<section>
    <div class='forms'>
        <!-- Search Form -->
        <form method="GET">
            <label for="search">Search:</label>
            <input type="text" id="search" name="search" placeholder="Title, Author, or Publisher">
            <button type="submit">Search</button>
        </form>

        <!-- Sort Form -->
        <form method="GET">
            <label for="sort">Sort By:</label>
            <select name="sort" id="sort">
                <option value="title">Book Title</option>
                <option value="auth_lname">Author's Last Name</option>
                <option value="pub_name">Publisher's Name</option>
            </select>
            <button type="submit" value="sort" name="sortbutton">Sort</button>
        </form>

        <!-- Show All Books Form -->
        <form method="GET">
            <button type="submit" name="showall">Show All Books</button>
        </form>
    </div>

    <div class='book-list'>
        <?php
        // Add a New Book
        if (isset($_POST['add_button'])) {
            // Retrieve the maximum BookID from the Books table
            $maxBookIDQuery = "SELECT MAX(BookID) AS MaxBookID FROM Books";
            $maxBookIDResult = mysqli_query($conn, $maxBookIDQuery);

            if ($maxBookIDResult && mysqli_num_rows($maxBookIDResult) > 0) {
                $row = mysqli_fetch_assoc($maxBookIDResult);
                $newBookID = $row['MaxBookID'] + 1;
            } else {
                // If no books exist start with BookID 1
                $newBookID = 1;
            }

            $newTitle = mysqli_real_escape_string($conn, $_POST['new_title']);
            $newAuthorID = mysqli_real_escape_string($conn, $_POST['new_author_id']);
            $newPubID = mysqli_real_escape_string($conn, $_POST['new_pub_id']);
            $newYrPub = mysqli_real_escape_string($conn, $_POST['new_yr_pub']);
            $newImgName = mysqli_real_escape_string($conn, $_POST['new_img_name'] . ".jpg");

            // Check for input for Year Published
            if (checkInput($newYrPub, 'Year Published', 'adding', 'book')) {

                // Check for duplicate entry
                if (checkForDuplicate($conn, "Books", ["Title", "AuthorID"], [$newTitle, $newAuthorID])) {
                    echo "<p>Error adding new book: '$newTitle' already exists.</p><br>";
                } else {

                    // Insert the new book into the database with the new BookID
                    $insertQuery = "INSERT INTO Books (BookID, Title, AuthorID, PubID, PubYr, Cover) VALUES (?, ?, ?, ?, ?, ?)";
                    $stmt = mysqli_prepare($conn, $insertQuery);
                    mysqli_stmt_bind_param($stmt, "isiiis", $newBookID, $newTitle, $newAuthorID, $newPubID, $newYrPub, $newImgName);

                    if (mysqli_stmt_execute($stmt)) {
                        echo "<p>New book '$newTitle' added successfully.</p><br>";
                    } else {
                        echo "<p>Error adding new book: " . mysqli_error($conn) . "</p><br>";
                    }
                    mysqli_stmt_close($stmt);
                }
            }
        }

        // Add a New Author
        if (isset($_POST['add_author_button'])) {
            $newFname = mysqli_real_escape_string($conn, $_POST['new_fname']);
            $newLname = mysqli_real_escape_string($conn, $_POST['new_lname']);

            // Query to get the next available AuthorID
            $getNextAuthorIDQuery = "SELECT MAX(AuthorID) AS NextAuthorID FROM Authors";
            $result = mysqli_query($conn, $getNextAuthorIDQuery);

            if ($result && mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
                $nextAuthorID = $row['NextAuthorID'] + 1;
            } else {
                // If no authors exist yet, start with AuthorID 1
                $nextAuthorID = 1;
            }

            if (checkForDuplicate($conn, "Authors", ["Fname", "Lname"], [$newFname, $newLname])) {
                echo "<p>Error adding new author: '$newFname $newLname' already exists.</p><br>";
            } else {
                // Insert the new author into the database
                $insertAuthorQuery = "INSERT INTO Authors (AuthorID, Fname, Lname) VALUES (?, ?, ?)";
                $stmt = mysqli_prepare($conn, $insertAuthorQuery);
                mysqli_stmt_bind_param($stmt, "iss", $nextAuthorID, $newFname, $newLname);

                if (mysqli_stmt_execute($stmt)) {
                    echo "<p>New author: $newFname $newLname added successfully.</p><br>";
                } else {
                    echo "<p>Error adding new author: " . mysqli_error($conn) . "</p><br>";
                }
                mysqli_stmt_close($stmt);
            }
        }

        // Add a New Publisher
        if (isset($_POST['add_pub_button'])) {
            $newPubName = mysqli_real_escape_string($conn, $_POST['new_pub_name']);

            // Query to get the next available PubID
            $getNextPubIDQuery = "SELECT MAX(PubID) AS NextPubID FROM Publishers";
            $result = mysqli_query($conn, $getNextPubIDQuery);

            if ($result && mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
                $nextPubID = $row['NextPubID'] + 1;
            } else {
                // If no publishers exist yet, start with PubID 1
                $nextPubID = 1;
            }

            if (checkForDuplicate($conn, "Publishers", ["Name"], [$newPubName])) {
                echo "<p>Error adding new publisher: '$newPubName' already exists.</p><br>";
            } else {
                // Insert the new publisher into the database
                $insertPubQuery = "INSERT INTO Publishers (PubID, Name) VALUES (?, ?)";
                $stmt = mysqli_prepare($conn, $insertPubQuery);
                mysqli_stmt_bind_param($stmt, "is", $nextPubID, $newPubName);

                if (mysqli_stmt_execute($stmt)) {
                    echo "<p>New publisher: '$newPubName' added successfully.</p><br>";
                } else {
                    echo "<p>Error adding new publisher: " . mysqli_error($conn) . "</p><br>";
                }
                mysqli_stmt_close($stmt);
            }
        }

        // Add Book to Favorites
        if (isset($_POST['add_to_favs']) && isset($_POST['book_id'])) {
            // Ensure the user is logged in
            if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == 1) {
                $userID = $_SESSION['user_id']; // Get the user's ID from the session
                $bookID = $_POST['book_id'];

                // Query to get the next available FavID
                $getNextFavIDQuery = "SELECT MAX(FavID) AS NextFavID FROM Favourites";
                $result = mysqli_query($conn, $getNextFavIDQuery);

                if ($result && mysqli_num_rows($result) > 0) {
                    $row = mysqli_fetch_assoc($result);
                    $nextFavID = $row['NextFavID'] + 1;
                } else {
                    // If no favorites exist yet, start with FavID 1
                    $nextFavID = 1;
                }

                // Check if the book is already in the user's favorites
                if (checkForDuplicate($conn, "Favourites", ["UserID", "BookID"], [$userID, $bookID])) {
                    echo "<p>This book is already in your favorites.</p><br>";
                } else {
                    // Add the book to favorites
                    $insertQuery = "INSERT INTO Favourites (FavID, UserID, BookID) VALUES (?, ?, ?)";
                    $stmt = mysqli_prepare($conn, $insertQuery);
                    mysqli_stmt_bind_param($stmt, "iii", $nextFavID, $userID, $bookID);

                    if (mysqli_stmt_execute($stmt)) {
                        echo "<p>Book added to favorites successfully.</p><br>";
                    } else {
                        echo "<p>Error adding the book to favorites: " . mysqli_error($conn) . "</p><br>";
                    }
                }
            }
        }

        // Display Books with edit form if user is logged in
        function displayBooks($result, $authors, $publishers, $conn) {
            echo "<div class='book-list'>";
            if ($result && mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_array($result)) {
                    echo "<div class='book-list-item'><img src='images/" . $row['Cover'] . "' alt='" . $row['Title'] . "'>";

                    if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == 1) {
                        $isEditing = isset($_POST['edit_book_id']) && $_POST['edit_book_id'] == $row['BookID'];
                        if ($isEditing) {
                            echo "<form method='POST' action='books.php'>";
                            echo "<input type='hidden' name='book_id' value='" . $row['BookID'] . "'>";
                            echo '<input type="text" name="title" value="' . $row['Title'] . '" required><br>';

                            // Dropdown for authors with the current author selected
                            echo '<label for="author_id">Author:</label>';
                            echo '<select name="author_id" id="author_id" required>';

                            foreach ($authors as $authorID => $authorName) {
                                $selected = ($authorID == $row['AuthorID']) ? "selected" : "";
                                echo "<option value='" . $authorID . "' $selected>" . $authorName . "</option>";
                            }
                            echo "</select><br>";

                            // Dropdown for publishers with the current publisher selected
                            echo '<label for="pub_id">Publisher:</label>';
                            echo '<select name="pub_id" id="pub_id" required>';

                            foreach ($publishers as $pubID => $pubName) {
                                $selected = ($pubID == $row['PubID']) ? "selected" : "";
                                echo "<option value='" . $pubID . "' $selected>" . $pubName . "</option>";
                            }
                            echo "</select><br>";

                            echo '<label for="yr_pub">Year Published:</label>';
                            echo '<input type="text" name="yr_pub" value="' . $row['PubYr'] . '" required><br>';
                            echo "<button type='submit' name='save_button'>Save</button>";
                            echo "<button type='submit' name='cancel_button'>Cancel</button>";
                            echo "</form>";
                        } else {
                            echo "<h3>" . $row['Title'] . "</h3><p>by " . $row['Fname'] . " " . $row['Lname'] .
                                "<br>Publisher: " . $row['Name'] . "<br>Year Published: " . $row['PubYr'] . "</p><br>";
                            echo "<form method='POST' action='books.php'>";
                            echo "<input type='hidden' name='edit_book_id' value='" . $row['BookID'] . "'>";
                            echo "<button type='submit' name='edit_button'>Edit</button></form>";
                        }
                    } else {
                        echo "<h3>" . $row['Title'] . "</h3><p>by " . $row['Fname'] . " " . $row['Lname'] .
                            "<br>Publisher: " . $row['Name'] . "<br>Year Published: " . $row['PubYr'] . "</p>";
                    }

                    echo "</div>";
                }
            }
        }

        // Edit Book Details
        if (isset($_POST['save_button']) && isset($_POST['book_id'])) {
            $bookID = $_POST['book_id'];
            $newTitle = isset($_POST['title']) ? mysqli_real_escape_string($conn, $_POST['title']) : '';
            $newAuthorID = mysqli_real_escape_string($conn, $_POST['author_id']);
            $newPubID = mysqli_real_escape_string($conn, $_POST['pub_id']);
            $newYrPub = mysqli_real_escape_string($conn, $_POST['yr_pub']);

            $selectQuery = "SELECT Title FROM Books WHERE BookID = ?";
            $stmt = mysqli_prepare($conn, $selectQuery);
            mysqli_stmt_bind_param($stmt, "i", $bookID);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_bind_result($stmt, $oldTitle);
            mysqli_stmt_fetch($stmt);
            mysqli_stmt_close($stmt);

            if (checkInput($newYrPub, 'Year Published', 'editing', $oldTitle)) {
                if (checkForDuplicate($conn, "Books", ["Title", "AuthorID"], [$newTitle, $newAuthorID])) {
                    echo "<p>Error editing book: A book with the same title, '$newTitle', and the same author already exists.</p><br>";
                } else {
                    $updateQuery = "UPDATE Books SET Title = ?, AuthorID = ?, PubID = ?, PubYr = ? WHERE BookID = ?";
                    $stmt = mysqli_prepare($conn, $updateQuery);
                    mysqli_stmt_bind_param($stmt, "siisi", $newTitle, $newAuthorID, $newPubID, $newYrPub, $bookID);

                    if (mysqli_stmt_execute($stmt)) {
                        echo "<p>Book '$newTitle' details updated successfully.</p><br>";
                    } else {
                        echo "<p>Error updating $oldTitle details: " . mysqli_error($conn) . "</p><br>";
                    }
                    mysqli_stmt_close($stmt);
                }
            }
        }
		
		// Search, Sort and Show all books
        if (isset($_GET['search'])) {
            $search = $_GET['search'];
            $booksearch = "SELECT * FROM Books
            JOIN Authors ON Books.AuthorID = Authors.AuthorID 
            JOIN Publishers ON Books.PubID = Publishers.PubID
            WHERE Books.Title LIKE '%$search%' OR Authors.Fname LIKE '%$search%' 
            OR Authors.Lname LIKE '%$search%' OR Publishers.Name LIKE '%$search%'";

            $searchresult = mysqli_query($conn, $booksearch);
            displayBooks($searchresult, $authors, $publishers, $conn);
			
        } elseif (isset($_GET['sort'])) {
            $sort = $_GET['sort'];
            $booksort = "SELECT * FROM Books
            JOIN Authors ON Books.AuthorID = Authors.AuthorID
            JOIN Publishers ON Books.PubID = Publishers.PubID
            ORDER BY
            CASE WHEN '$sort' = 'auth_lname' THEN Authors.Lname END,
            CASE WHEN '$sort' = 'title' THEN Books.Title END,
            CASE WHEN '$sort' = 'pub_name' THEN Publishers.Name END";

            $sortresult = mysqli_query($conn, $booksort);
            displayBooks($sortresult, $authors, $publishers, $conn);
			
        } else {
            $booksquery = "SELECT * FROM Books, Authors, Publishers
            WHERE Books.AuthorID = Authors.AuthorID
            AND Books.PubID = Publishers.PubID";
            $booksqueryresult = mysqli_query($conn, $booksquery);
            displayBooks($booksqueryresult, $authors, $publishers, $conn);
        }

        if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == 1) {
			// Add a New Book HTML Form
            echo '<div class="book-list-item">
            <h2>Add a New Book</h2>
            <form method="POST">
            <label for="new_title">Title:</label>
            <input type="text" id="new_title" name="new_title" required><br>
            <label for="new_author_id">Author:</label>
            <select name="new_author_id" id="new_author_id" required>
            <option value="" disabled selected>Select an author</option>';

            foreach ($authors as $authorID => $authorName) {
                echo "<option value='" . $authorID . "'>" . $authorName . "</option>";
            }
            echo '</select><br>
            <label for="new_pub_id">Publisher:</label>
            <select name="new_pub_id" id="new_pub_id" required>
            <option value="" disabled selected>Select a publisher</option>';

            foreach ($publishers as $pubID => $pubName) {
                echo "<option value='" . $pubID . "'>" . $pubName . "</option>";
            }
            echo '</select><br>
            <label for="new_yr_pub">Year Published:</label>
            <input type="text" id="new_yr_pub" name="new_yr_pub" required><br>

            <label for="new_img_name">Image Name:</label>
            <input type="text" id="new_img_name" name="new_img_name" required><br>
            <button type="submit" name="add_button">Add Book</button></form></div>';

            // Add a New Author HTML Form
            echo '<div class="book-list-item">
            <h2>Add a New Author</h2>
            <form method="POST">
            <label for="new_fname">First Name:</label>
            <input type="text" id="new_fname" name="new_fname" required><br>
            <label for="new_lname">Last Name:</label>
            <input type="text" id="new_lname" name="new_lname" required><br>
            <button type="submit" name="add_author_button">Add Author</button></form></div>';

            // Add a New Publisher HTML Form
            echo '<div class="book-list-item">
            <h2>Add a New Publisher</h2>
            <form method="POST">
            <label for="new_pub_name">Publisher Name:</label>
            <input type="text" id="new_pub_name" name="new_pub_name" required><br>
            <button type="submit" name="add_pub_button">Add Publisher</button></form></div>';
        }
        ?>
</div>
</section>

<!-- Footer -->
<footer>
    <p>&copy; 2023 Gabrielle's Website. All rights reserved.</p>
</footer>
</body>
</html>
